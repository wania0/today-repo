from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import EmployeerGenericCreateUpdateApiView, JobPostModelViewSet, JobSeekerModelViewSet, NotificationModelViewSet


router = DefaultRouter()
router.register("job-post", JobPostModelViewSet, basename="job_post"),
router.register("job-seeker", JobSeekerModelViewSet, basename="job_seeker"),

router.register("notification", NotificationModelViewSet)
# router.register("application", ApplicationModelViewSet)

urlpatterns = [
    path('employeer/profile/', EmployeerGenericCreateUpdateApiView.as_view(), name="profile")

] + router.urls

